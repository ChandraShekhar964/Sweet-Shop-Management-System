import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { api, PurchaseHistory } from '../../lib/api';

interface PurchaseHistoryModalProps {
  onClose: () => void;
}

export const PurchaseHistoryModal = ({ onClose }: PurchaseHistoryModalProps) => {
  const [purchases, setPurchases] = useState<PurchaseHistory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPurchases();
  }, []);

  const loadPurchases = async () => {
    try {
      const data = await api.getPurchaseHistory();
      setPurchases(data);
    } catch (error) {
      console.error('Failed to load purchase history:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-hidden">
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-bold text-gray-800">Purchase History</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <div className="p-6 overflow-y-auto max-h-[70vh]">
          {loading ? (
            <div className="text-center py-8 text-gray-600">Loading...</div>
          ) : purchases.length === 0 ? (
            <div className="text-center py-8 text-gray-600">No purchase history yet</div>
          ) : (
            <div className="space-y-4">
              {purchases.map((purchase) => (
                <div
                  key={purchase.id}
                  className="bg-gray-50 rounded-lg p-4 flex justify-between items-center"
                >
                  <div>
                    <h3 className="font-semibold text-gray-800">{purchase.sweets.name}</h3>
                    <p className="text-sm text-gray-600">
                      Quantity: {purchase.quantity} × ${purchase.sweets.price.toFixed(2)}
                    </p>
                    <p className="text-xs text-gray-500">
                      {new Date(purchase.created_at).toLocaleString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-green-600">
                      ${purchase.total_price.toFixed(2)}
                    </p>
                  </div>
                </div>
              ))}

              <div className="border-t pt-4 mt-4">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold text-gray-800">Total Spent:</span>
                  <span className="text-2xl font-bold text-green-600">
                    ${purchases.reduce((sum, p) => sum + p.total_price, 0).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

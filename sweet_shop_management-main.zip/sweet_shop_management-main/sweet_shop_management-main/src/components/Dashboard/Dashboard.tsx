import { useState, useEffect } from 'react';
import { Plus, Search, LogOut, History } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { api, Sweet } from '../../lib/api';
import { SweetCard } from '../Sweets/SweetCard';
import { SweetFormModal } from '../Sweets/SweetFormModal';
import { PurchaseHistoryModal } from './PurchaseHistoryModal';

export const Dashboard = () => {
  const { user, logout, isAdmin } = useAuth();
  const [sweets, setSweets] = useState<Sweet[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [minPrice, setMinPrice] = useState<number | undefined>();
  const [maxPrice, setMaxPrice] = useState<number | undefined>();
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingSweet, setEditingSweet] = useState<Sweet | undefined>();
  const [showHistory, setShowHistory] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const categories = ['chocolate', 'candy', 'gummy', 'lollipop', 'caramel'];

  useEffect(() => {
    loadSweets();
  }, []);

  const loadSweets = async () => {
    try {
      const data = await api.getAllSweets();
      setSweets(data);
    } catch (error: any) {
      showMessage('error', error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    setLoading(true);
    try {
      const data = await api.searchSweets({
        name: searchTerm || undefined,
        category: categoryFilter || undefined,
        minPrice,
        maxPrice,
      });
      setSweets(data);
    } catch (error: any) {
      showMessage('error', error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleClearFilters = () => {
    setSearchTerm('');
    setCategoryFilter('');
    setMinPrice(undefined);
    setMaxPrice(undefined);
    loadSweets();
  };

  const handlePurchase = async (sweetId: string, quantity: number) => {
    try {
      await api.purchaseSweet(sweetId, quantity);
      showMessage('success', 'Purchase successful!');
      await loadSweets();
    } catch (error: any) {
      showMessage('error', error.message);
    }
  };

  const handleAddSweet = async (sweetData: any) => {
    try {
      await api.createSweet(sweetData);
      showMessage('success', 'Sweet added successfully!');
      await loadSweets();
    } catch (error: any) {
      showMessage('error', error.message);
      throw error;
    }
  };

  const handleUpdateSweet = async (sweetData: any) => {
    if (!editingSweet) return;
    try {
      await api.updateSweet(editingSweet.id, sweetData);
      showMessage('success', 'Sweet updated successfully!');
      setEditingSweet(undefined);
      await loadSweets();
    } catch (error: any) {
      showMessage('error', error.message);
      throw error;
    }
  };

  const handleDeleteSweet = async (sweetId: string) => {
    if (!confirm('Are you sure you want to delete this sweet?')) return;

    try {
      await api.deleteSweet(sweetId);
      showMessage('success', 'Sweet deleted successfully!');
      await loadSweets();
    } catch (error: any) {
      showMessage('error', error.message);
    }
  };

  const handleRestock = async (sweetId: string, quantity: number) => {
    try {
      await api.restockSweet(sweetId, quantity);
      showMessage('success', 'Sweet restocked successfully!');
      await loadSweets();
    } catch (error: any) {
      showMessage('error', error.message);
    }
  };

  const showMessage = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 5000);
  };

  if (loading && sweets.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 to-blue-50 flex items-center justify-center">
        <div className="text-2xl text-gray-600">Loading sweets...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-blue-50">
      <nav className="bg-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-gray-800">Sweet Shop</h1>
            <div className="flex items-center gap-4">
              <span className="text-gray-600">
                Welcome, {user?.full_name || user?.email}
                {isAdmin && <span className="ml-2 px-2 py-1 bg-yellow-400 text-xs rounded-full">ADMIN</span>}
              </span>
              <button
                onClick={() => setShowHistory(true)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
              >
                <History size={18} />
                History
              </button>
              <button
                onClick={logout}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2"
              >
                <LogOut size={18} />
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {message && (
          <div
            className={`mb-6 p-4 rounded-lg ${
              message.type === 'success'
                ? 'bg-green-100 border border-green-400 text-green-700'
                : 'bg-red-100 border border-red-400 text-red-700'
            }`}
          >
            {message.text}
          </div>
        )}

        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-gray-800">Search & Filter</h2>
            {isAdmin && (
              <button
                onClick={() => setShowAddModal(true)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Plus size={18} />
                Add Sweet
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <input
              type="text"
              placeholder="Search by name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            />

            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                </option>
              ))}
            </select>

            <input
              type="number"
              placeholder="Min Price"
              value={minPrice || ''}
              onChange={(e) => setMinPrice(e.target.value ? parseFloat(e.target.value) : undefined)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            />

            <input
              type="number"
              placeholder="Max Price"
              value={maxPrice || ''}
              onChange={(e) => setMaxPrice(e.target.value ? parseFloat(e.target.value) : undefined)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            />

            <div className="flex gap-2">
              <button
                onClick={handleSearch}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
              >
                <Search size={18} />
                Search
              </button>
              <button
                onClick={handleClearFilters}
                className="px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
              >
                Clear
              </button>
            </div>
          </div>
        </div>

        {sweets.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-xl text-gray-600">No sweets found. Try adjusting your filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {sweets.map((sweet) => (
              <SweetCard
                key={sweet.id}
                sweet={sweet}
                isAdmin={isAdmin}
                onPurchase={handlePurchase}
                onEdit={setEditingSweet}
                onDelete={handleDeleteSweet}
                onRestock={handleRestock}
              />
            ))}
          </div>
        )}
      </div>

      {showAddModal && (
        <SweetFormModal
          onClose={() => setShowAddModal(false)}
          onSave={handleAddSweet}
        />
      )}

      {editingSweet && (
        <SweetFormModal
          sweet={editingSweet}
          onClose={() => setEditingSweet(undefined)}
          onSave={handleUpdateSweet}
        />
      )}

      {showHistory && (
        <PurchaseHistoryModal onClose={() => setShowHistory(false)} />
      )}
    </div>
  );
};

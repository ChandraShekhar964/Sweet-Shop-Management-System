const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001/api';

export interface User {
  id: string;
  email: string;
  full_name?: string;
  role: 'user' | 'admin';
}

export interface Sweet {
  id: string;
  name: string;
  category: string;
  description?: string;
  price: number;
  quantity: number;
  image_url?: string;
  created_at: string;
}

export interface PurchaseHistory {
  id: string;
  sweet_id: string;
  user_id: string;
  quantity: number;
  total_price: number;
  created_at: string;
  sweets: Sweet;
}

class ApiService {
  private getAuthHeader(): HeadersInit {
    const token = localStorage.getItem('authToken');
    return {
      'Content-Type': 'application/json',
      ...(token && { Authorization: `Bearer ${token}` }),
    };
  }

  async register(email: string, password: string, full_name?: string) {
    const response = await fetch(`${API_BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, full_name }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Registration failed');
    }

    const data = await response.json();
    localStorage.setItem('authToken', data.data.token);
    return data.data;
  }

  async login(email: string, password: string) {
    const response = await fetch(`${API_BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Login failed');
    }

    const data = await response.json();
    localStorage.setItem('authToken', data.data.token);
    return data.data;
  }

  async getProfile(): Promise<User> {
    const response = await fetch(`${API_BASE_URL}/auth/profile`, {
      headers: this.getAuthHeader(),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch profile');
    }

    const data = await response.json();
    return data.data.user;
  }

  async getAllSweets(): Promise<Sweet[]> {
    const response = await fetch(`${API_BASE_URL}/sweets`);

    if (!response.ok) {
      throw new Error('Failed to fetch sweets');
    }

    const data = await response.json();
    return data.data.sweets;
  }

  async searchSweets(params: {
    name?: string;
    category?: string;
    minPrice?: number;
    maxPrice?: number;
  }): Promise<Sweet[]> {
    const queryParams = new URLSearchParams();
    if (params.name) queryParams.append('name', params.name);
    if (params.category) queryParams.append('category', params.category);
    if (params.minPrice !== undefined) queryParams.append('minPrice', params.minPrice.toString());
    if (params.maxPrice !== undefined) queryParams.append('maxPrice', params.maxPrice.toString());

    const response = await fetch(`${API_BASE_URL}/sweets/search?${queryParams}`);

    if (!response.ok) {
      throw new Error('Failed to search sweets');
    }

    const data = await response.json();
    return data.data.sweets;
  }

  async createSweet(sweet: {
    name: string;
    category: string;
    description?: string;
    price: number;
    quantity: number;
    image_url?: string;
  }): Promise<Sweet> {
    const response = await fetch(`${API_BASE_URL}/sweets`, {
      method: 'POST',
      headers: this.getAuthHeader(),
      body: JSON.stringify(sweet),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to create sweet');
    }

    const data = await response.json();
    return data.data.sweet;
  }

  async updateSweet(id: string, updates: Partial<Sweet>): Promise<Sweet> {
    const response = await fetch(`${API_BASE_URL}/sweets/${id}`, {
      method: 'PUT',
      headers: this.getAuthHeader(),
      body: JSON.stringify(updates),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to update sweet');
    }

    const data = await response.json();
    return data.data.sweet;
  }

  async deleteSweet(id: string): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/sweets/${id}`, {
      method: 'DELETE',
      headers: this.getAuthHeader(),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Failed to delete sweet');
    }
  }

  async purchaseSweet(id: string, quantity: number): Promise<void> {
    const response = await fetch(`${API_BASE_URL}/sweets/${id}/purchase`, {
      method: 'POST',
      headers: this.getAuthHeader(),
      body: JSON.stringify({ quantity }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Purchase failed');
    }
  }

  async restockSweet(id: string, quantity: number): Promise<Sweet> {
    const response = await fetch(`${API_BASE_URL}/sweets/${id}/restock`, {
      method: 'POST',
      headers: this.getAuthHeader(),
      body: JSON.stringify({ quantity }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Restock failed');
    }

    const data = await response.json();
    return data.data.sweet;
  }

  async getPurchaseHistory(): Promise<PurchaseHistory[]> {
    const response = await fetch(`${API_BASE_URL}/sweets/purchases`, {
      headers: this.getAuthHeader(),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch purchase history');
    }

    const data = await response.json();
    return data.data.purchases;
  }

  logout() {
    localStorage.removeItem('authToken');
  }
}

export const api = new ApiService();

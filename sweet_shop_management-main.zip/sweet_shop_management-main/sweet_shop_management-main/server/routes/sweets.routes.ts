import { Router } from 'express';
import {
  getAllSweets,
  searchSweets,
  getSweetById,
  createSweet,
  updateSweet,
  deleteSweet,
  purchaseSweet,
  restockSweet,
  getPurchaseHistory,
} from '../controllers/sweets.controller.js';
import { authenticateToken, requireAdmin } from '../middleware/auth.js';

const router = Router();

router.get('/', getAllSweets);
router.get('/search', searchSweets);
router.get('/purchases', authenticateToken, getPurchaseHistory);
router.get('/:id', getSweetById);
router.post('/', authenticateToken, createSweet);
router.put('/:id', authenticateToken, updateSweet);
router.delete('/:id', authenticateToken, requireAdmin, deleteSweet);
router.post('/:id/purchase', authenticateToken, purchaseSweet);
router.post('/:id/restock', authenticateToken, requireAdmin, restockSweet);

export default router;

import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../index.js';

describe('Sweets API', () => {
  let authToken: string;
  let sweetId: string;
  const testUser = {
    email: `sweettest${Date.now()}@example.com`,
    password: 'password123',
  };

  beforeAll(async () => {
    const response = await request(app)
      .post('/api/auth/register')
      .send(testUser);
    authToken = response.body.data.token;
  });

  describe('GET /api/sweets', () => {
    it('should get all sweets without authentication', async () => {
      const response = await request(app)
        .get('/api/sweets')
        .expect(200);

      expect(response.body.status).toBe('success');
      expect(response.body.data).toHaveProperty('sweets');
      expect(Array.isArray(response.body.data.sweets)).toBe(true);
    });
  });

  describe('POST /api/sweets', () => {
    it('should create a new sweet with valid data', async () => {
      const newSweet = {
        name: 'Test Chocolate',
        category: 'chocolate',
        description: 'Delicious test chocolate',
        price: 5.99,
        quantity: 50,
      };

      const response = await request(app)
        .post('/api/sweets')
        .set('Authorization', `Bearer ${authToken}`)
        .send(newSweet)
        .expect(201);

      expect(response.body.status).toBe('success');
      expect(response.body.data.sweet).toHaveProperty('id');
      expect(response.body.data.sweet.name).toBe(newSweet.name);
      expect(response.body.data.sweet.price).toBe(newSweet.price);

      sweetId = response.body.data.sweet.id;
    });

    it('should fail to create sweet without authentication', async () => {
      const newSweet = {
        name: 'Test Sweet',
        category: 'candy',
        price: 2.99,
        quantity: 100,
      };

      const response = await request(app)
        .post('/api/sweets')
        .send(newSweet)
        .expect(401);

      expect(response.body.status).toBe('error');
    });

    it('should fail to create sweet with missing required fields', async () => {
      const response = await request(app)
        .post('/api/sweets')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Incomplete Sweet',
        })
        .expect(400);

      expect(response.body.status).toBe('error');
      expect(response.body.message).toContain('required');
    });

    it('should fail to create sweet with negative price', async () => {
      const response = await request(app)
        .post('/api/sweets')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Bad Price Sweet',
          category: 'candy',
          price: -5,
          quantity: 10,
        })
        .expect(400);

      expect(response.body.status).toBe('error');
      expect(response.body.message).toContain('non-negative');
    });
  });

  describe('GET /api/sweets/:id', () => {
    it('should get a sweet by id', async () => {
      const response = await request(app)
        .get(`/api/sweets/${sweetId}`)
        .expect(200);

      expect(response.body.status).toBe('success');
      expect(response.body.data.sweet.id).toBe(sweetId);
    });

    it('should return 404 for non-existent sweet', async () => {
      const fakeId = '00000000-0000-0000-0000-000000000000';
      const response = await request(app)
        .get(`/api/sweets/${fakeId}`)
        .expect(404);

      expect(response.body.status).toBe('error');
      expect(response.body.message).toContain('not found');
    });
  });

  describe('GET /api/sweets/search', () => {
    it('should search sweets by name', async () => {
      const response = await request(app)
        .get('/api/sweets/search?name=Test')
        .expect(200);

      expect(response.body.status).toBe('success');
      expect(Array.isArray(response.body.data.sweets)).toBe(true);
    });

    it('should search sweets by category', async () => {
      const response = await request(app)
        .get('/api/sweets/search?category=chocolate')
        .expect(200);

      expect(response.body.status).toBe('success');
      expect(Array.isArray(response.body.data.sweets)).toBe(true);
    });

    it('should search sweets by price range', async () => {
      const response = await request(app)
        .get('/api/sweets/search?minPrice=1&maxPrice=10')
        .expect(200);

      expect(response.body.status).toBe('success');
      expect(Array.isArray(response.body.data.sweets)).toBe(true);
    });
  });

  describe('PUT /api/sweets/:id', () => {
    it('should update a sweet successfully', async () => {
      const updates = {
        name: 'Updated Test Chocolate',
        price: 6.99,
      };

      const response = await request(app)
        .put(`/api/sweets/${sweetId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .send(updates)
        .expect(200);

      expect(response.body.status).toBe('success');
      expect(response.body.data.sweet.name).toBe(updates.name);
      expect(response.body.data.sweet.price).toBe(updates.price);
    });

    it('should fail to update without authentication', async () => {
      const response = await request(app)
        .put(`/api/sweets/${sweetId}`)
        .send({ name: 'Updated' })
        .expect(401);

      expect(response.body.status).toBe('error');
    });
  });

  describe('POST /api/sweets/:id/purchase', () => {
    it('should purchase a sweet successfully', async () => {
      const response = await request(app)
        .post(`/api/sweets/${sweetId}/purchase`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({ quantity: 2 })
        .expect(200);

      expect(response.body.status).toBe('success');
      expect(response.body.message).toContain('successful');
      expect(response.body.data).toHaveProperty('remainingStock');
    });

    it('should fail to purchase without authentication', async () => {
      const response = await request(app)
        .post(`/api/sweets/${sweetId}/purchase`)
        .send({ quantity: 1 })
        .expect(401);

      expect(response.body.status).toBe('error');
    });

    it('should fail to purchase with invalid quantity', async () => {
      const response = await request(app)
        .post(`/api/sweets/${sweetId}/purchase`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({ quantity: 0 })
        .expect(400);

      expect(response.body.status).toBe('error');
      expect(response.body.message).toContain('greater than 0');
    });

    it('should fail to purchase more than available stock', async () => {
      const response = await request(app)
        .post(`/api/sweets/${sweetId}/purchase`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({ quantity: 10000 })
        .expect(400);

      expect(response.body.status).toBe('error');
      expect(response.body.message).toContain('Insufficient stock');
    });
  });

  describe('GET /api/sweets/purchases', () => {
    it('should get purchase history for authenticated user', async () => {
      const response = await request(app)
        .get('/api/sweets/purchases')
        .set('Authorization', `Bearer ${authToken}`)
        .expect(200);

      expect(response.body.status).toBe('success');
      expect(response.body.data).toHaveProperty('purchases');
      expect(Array.isArray(response.body.data.purchases)).toBe(true);
    });

    it('should fail to get purchase history without authentication', async () => {
      const response = await request(app)
        .get('/api/sweets/purchases')
        .expect(401);

      expect(response.body.status).toBe('error');
    });
  });
});

import { Request } from 'express';

export interface User {
  id: string;
  email: string;
  full_name?: string;
  role: 'user' | 'admin';
  created_at: string;
  updated_at: string;
}

export interface Sweet {
  id: string;
  name: string;
  category: string;
  description?: string;
  price: number;
  quantity: number;
  image_url?: string;
  created_by?: string;
  created_at: string;
  updated_at: string;
}

export interface PurchaseHistory {
  id: string;
  sweet_id: string;
  user_id: string;
  quantity: number;
  total_price: number;
  created_at: string;
}

export interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: string;
  };
}

export interface RegisterInput {
  email: string;
  password: string;
  full_name?: string;
}

export interface LoginInput {
  email: string;
  password: string;
}

export interface CreateSweetInput {
  name: string;
  category: string;
  description?: string;
  price: number;
  quantity: number;
  image_url?: string;
}

export interface UpdateSweetInput {
  name?: string;
  category?: string;
  description?: string;
  price?: number;
  quantity?: number;
  image_url?: string;
}

export interface PurchaseInput {
  quantity: number;
}

export interface RestockInput {
  quantity: number;
}

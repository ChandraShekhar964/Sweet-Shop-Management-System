import { useState } from 'react';
import { ShoppingCart, Edit, Trash2, Package } from 'lucide-react';
import { Sweet } from '../../lib/api';

interface SweetCardProps {
  sweet: Sweet;
  isAdmin: boolean;
  onPurchase: (sweetId: string, quantity: number) => Promise<void>;
  onEdit?: (sweet: Sweet) => void;
  onDelete?: (sweetId: string) => Promise<void>;
  onRestock?: (sweetId: string, quantity: number) => Promise<void>;
}

export const SweetCard = ({
  sweet,
  isAdmin,
  onPurchase,
  onEdit,
  onDelete,
  onRestock,
}: SweetCardProps) => {
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(false);
  const [showRestock, setShowRestock] = useState(false);
  const [restockAmount, setRestockAmount] = useState(10);

  const handlePurchase = async () => {
    setLoading(true);
    try {
      await onPurchase(sweet.id, quantity);
      setQuantity(1);
    } finally {
      setLoading(false);
    }
  };

  const handleRestock = async () => {
    if (onRestock) {
      setLoading(true);
      try {
        await onRestock(sweet.id, restockAmount);
        setShowRestock(false);
        setRestockAmount(10);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow">
      <div className="h-48 overflow-hidden bg-gray-200">
        <img
          src={sweet.image_url || 'https://images.pexels.com/photos/1833337/pexels-photo-1833337.jpeg'}
          alt={sweet.name}
          className="w-full h-full object-cover"
        />
      </div>

      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold text-gray-800">{sweet.name}</h3>
          <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
            {sweet.category}
          </span>
        </div>

        {sweet.description && (
          <p className="text-gray-600 text-sm mb-3">{sweet.description}</p>
        )}

        <div className="flex justify-between items-center mb-4">
          <span className="text-2xl font-bold text-green-600">${sweet.price.toFixed(2)}</span>
          <span className={`text-sm ${sweet.quantity > 0 ? 'text-gray-600' : 'text-red-600'}`}>
            Stock: {sweet.quantity}
          </span>
        </div>

        {!showRestock && (
          <>
            <div className="flex gap-2 mb-3">
              <input
                type="number"
                min="1"
                max={sweet.quantity}
                value={quantity}
                onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                disabled={sweet.quantity === 0}
                className="w-20 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={handlePurchase}
                disabled={sweet.quantity === 0 || loading}
                className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <ShoppingCart size={18} />
                {loading ? 'Processing...' : 'Purchase'}
              </button>
            </div>

            {isAdmin && (
              <div className="flex gap-2">
                <button
                  onClick={() => onEdit && onEdit(sweet)}
                  className="flex-1 bg-yellow-500 text-white py-2 px-3 rounded-lg hover:bg-yellow-600 transition-colors flex items-center justify-center gap-2"
                >
                  <Edit size={16} />
                  Edit
                </button>
                <button
                  onClick={() => setShowRestock(true)}
                  className="flex-1 bg-green-500 text-white py-2 px-3 rounded-lg hover:bg-green-600 transition-colors flex items-center justify-center gap-2"
                >
                  <Package size={16} />
                  Restock
                </button>
                <button
                  onClick={() => onDelete && onDelete(sweet.id)}
                  className="bg-red-500 text-white py-2 px-3 rounded-lg hover:bg-red-600 transition-colors"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            )}
          </>
        )}

        {showRestock && (
          <div className="space-y-2">
            <div className="flex gap-2">
              <input
                type="number"
                min="1"
                value={restockAmount}
                onChange={(e) => setRestockAmount(parseInt(e.target.value) || 1)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                placeholder="Amount to add"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleRestock}
                disabled={loading}
                className="flex-1 bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors disabled:bg-gray-400"
              >
                {loading ? 'Adding...' : 'Confirm Restock'}
              </button>
              <button
                onClick={() => setShowRestock(false)}
                className="flex-1 bg-gray-500 text-white py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

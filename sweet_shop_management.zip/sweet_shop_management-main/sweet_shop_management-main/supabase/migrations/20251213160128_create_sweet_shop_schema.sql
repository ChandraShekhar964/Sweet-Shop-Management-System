/*
  # Sweet Shop Management System Database Schema

  ## Overview
  This migration creates the core database structure for the Sweet Shop Management System,
  including user profiles and sweets inventory management.

  ## New Tables
  
  ### 1. profiles
  Extends auth.users with additional user information
  - `id` (uuid, primary key) - References auth.users(id)
  - `email` (text) - User's email address
  - `full_name` (text) - User's full name
  - `role` (text) - User role: 'user' or 'admin'
  - `created_at` (timestamptz) - Account creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 2. sweets
  Stores information about available sweets in the shop
  - `id` (uuid, primary key) - Unique identifier
  - `name` (text) - Sweet name
  - `category` (text) - Sweet category (chocolate, candy, gummy, etc.)
  - `description` (text) - Detailed description
  - `price` (decimal) - Price per unit
  - `quantity` (integer) - Available stock quantity
  - `image_url` (text) - Optional image URL
  - `created_by` (uuid) - References profiles(id)
  - `created_at` (timestamptz) - Creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 3. purchase_history
  Tracks all sweet purchases for auditing
  - `id` (uuid, primary key) - Unique identifier
  - `sweet_id` (uuid) - References sweets(id)
  - `user_id` (uuid) - References profiles(id)
  - `quantity` (integer) - Quantity purchased
  - `total_price` (decimal) - Total purchase price
  - `created_at` (timestamptz) - Purchase timestamp

  ## Security
  
  ### Row Level Security (RLS)
  All tables have RLS enabled with the following policies:
  
  #### profiles table:
  - Users can read their own profile
  - Users can update their own profile (except role)
  - Admins can read all profiles
  
  #### sweets table:
  - Anyone (authenticated or not) can view sweets
  - Authenticated users can create sweets
  - Only the creator or admins can update sweets
  - Only admins can delete sweets
  
  #### purchase_history table:
  - Users can view their own purchase history
  - Admins can view all purchase history
  - Users can create purchase records (when buying)

  ## Important Notes
  1. The first user to register should be manually set as admin via SQL
  2. All prices are stored as decimal(10,2) for precision
  3. Quantity cannot be negative (check constraint)
  4. Default role is 'user' for new registrations
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create sweets table
CREATE TABLE IF NOT EXISTS sweets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  category text NOT NULL,
  description text,
  price decimal(10,2) NOT NULL CHECK (price >= 0),
  quantity integer NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  image_url text,
  created_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create purchase_history table
CREATE TABLE IF NOT EXISTS purchase_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sweet_id uuid REFERENCES sweets(id) ON DELETE CASCADE,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE,
  quantity integer NOT NULL CHECK (quantity > 0),
  total_price decimal(10,2) NOT NULL CHECK (total_price >= 0),
  created_at timestamptz DEFAULT now()
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_sweets_category ON sweets(category);
CREATE INDEX IF NOT EXISTS idx_sweets_name ON sweets(name);
CREATE INDEX IF NOT EXISTS idx_sweets_price ON sweets(price);
CREATE INDEX IF NOT EXISTS idx_purchase_history_user_id ON purchase_history(user_id);
CREATE INDEX IF NOT EXISTS idx_purchase_history_sweet_id ON purchase_history(sweet_id);

-- Create function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at
DROP TRIGGER IF EXISTS update_profiles_updated_at ON profiles;
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_sweets_updated_at ON sweets;
CREATE TRIGGER update_sweets_updated_at
  BEFORE UPDATE ON sweets
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE sweets ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_history ENABLE ROW LEVEL SECURITY;

-- Policies for profiles table
CREATE POLICY "Users can view own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Admins can view all profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (
    auth.uid() = id 
    AND role = (SELECT role FROM profiles WHERE id = auth.uid())
  );

CREATE POLICY "Users can insert own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Policies for sweets table
CREATE POLICY "Anyone can view sweets"
  ON sweets
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Public can view sweets"
  ON sweets
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Authenticated users can create sweets"
  ON sweets
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Creators and admins can update sweets"
  ON sweets
  FOR UPDATE
  TO authenticated
  USING (
    created_by = auth.uid()
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    created_by = auth.uid()
    OR EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Only admins can delete sweets"
  ON sweets
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Policies for purchase_history table
CREATE POLICY "Users can view own purchase history"
  ON purchase_history
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admins can view all purchase history"
  ON purchase_history
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

CREATE POLICY "Users can create purchase records"
  ON purchase_history
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

-- Function to handle new user registration
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    'user'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to automatically create profile on user signup
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Insert some sample sweets data for testing
INSERT INTO sweets (name, category, description, price, quantity, image_url) VALUES
  ('Milk Chocolate Bar', 'chocolate', 'Smooth and creamy milk chocolate', 2.50, 100, 'https://images.pexels.com/photos/65882/chocolate-dark-coffee-confiserie-65882.jpeg'),
  ('Dark Chocolate Truffle', 'chocolate', 'Rich dark chocolate with cocoa filling', 3.50, 50, 'https://images.pexels.com/photos/918327/pexels-photo-918327.jpeg'),
  ('Strawberry Gummies', 'gummy', 'Chewy strawberry-flavored gummy candies', 1.99, 200, 'https://images.pexels.com/photos/3735139/pexels-photo-3735139.jpeg'),
  ('Sour Worms', 'gummy', 'Tangy sour gummy worms', 2.25, 150, 'https://images.pexels.com/photos/3991141/pexels-photo-3991141.jpeg'),
  ('Caramel Chews', 'candy', 'Soft and chewy caramel candies', 1.75, 120, 'https://images.pexels.com/photos/3693019/pexels-photo-3693019.jpeg'),
  ('Peppermint Sticks', 'candy', 'Classic striped peppermint candy sticks', 1.50, 80, 'https://images.pexels.com/photos/1334606/pexels-photo-1334606.jpeg'),
  ('Lollipops', 'candy', 'Colorful fruit-flavored lollipops', 0.99, 300, 'https://images.pexels.com/photos/3719862/pexels-photo-3719862.jpeg'),
  ('Chocolate Fudge', 'chocolate', 'Decadent chocolate fudge squares', 4.00, 60, 'https://images.pexels.com/photos/1854652/pexels-photo-1854652.jpeg')
ON CONFLICT DO NOTHING;

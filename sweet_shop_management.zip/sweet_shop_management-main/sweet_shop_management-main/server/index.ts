import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/auth.routes.js';
import sweetsRoutes from './routes/sweets.routes.js';
import { errorHandler } from './middleware/errorHandler.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'Sweet Shop API is running' });
});

app.use('/api/auth', authRoutes);
app.use('/api/sweets', sweetsRoutes);

app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`🍬 Sweet Shop API running on port ${PORT}`);
});

export default app;

import { Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { supabase } from '../config/supabase.js';
import { AuthRequest, RegisterInput, LoginInput } from '../types/index.js';
import { AppError } from '../middleware/errorHandler.js';

export const register = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    const { email, password, full_name }: RegisterInput = req.body;

    if (!email || !password) {
      return next(new AppError('Email and password are required', 400));
    }

    if (password.length < 6) {
      return next(new AppError('Password must be at least 6 characters', 400));
    }

    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          full_name: full_name || '',
        },
      },
    });

    if (authError) {
      return next(new AppError(authError.message, 400));
    }

    if (!authData.user) {
      return next(new AppError('Failed to create user', 500));
    }

    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', authData.user.id)
      .single();

    if (profileError) {
      return next(new AppError('Failed to create user profile', 500));
    }

    const token = jwt.sign(
      {
        id: profile.id,
        email: profile.email,
        role: profile.role,
      },
      process.env.JWT_SECRET!,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      status: 'success',
      data: {
        user: {
          id: profile.id,
          email: profile.email,
          full_name: profile.full_name,
          role: profile.role,
        },
        token,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const login = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    const { email, password }: LoginInput = req.body;

    if (!email || !password) {
      return next(new AppError('Email and password are required', 400));
    }

    const { data: authData, error: authError } =
      await supabase.auth.signInWithPassword({
        email,
        password,
      });

    if (authError) {
      return next(new AppError('Invalid email or password', 401));
    }

    if (!authData.user) {
      return next(new AppError('Authentication failed', 401));
    }

    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', authData.user.id)
      .single();

    if (profileError) {
      return next(new AppError('Failed to fetch user profile', 500));
    }

    const token = jwt.sign(
      {
        id: profile.id,
        email: profile.email,
        role: profile.role,
      },
      process.env.JWT_SECRET!,
      { expiresIn: '7d' }
    );

    res.json({
      status: 'success',
      data: {
        user: {
          id: profile.id,
          email: profile.email,
          full_name: profile.full_name,
          role: profile.role,
        },
        token,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const getProfile = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    if (!req.user) {
      return next(new AppError('Authentication required', 401));
    }

    const { data: profile, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', req.user.id)
      .single();

    if (error) {
      return next(new AppError('Failed to fetch profile', 500));
    }

    res.json({
      status: 'success',
      data: {
        user: profile,
      },
    });
  } catch (error) {
    next(error);
  }
};

import { Response, NextFunction } from 'express';
import { supabase } from '../config/supabase.js';
import {
  AuthRequest,
  CreateSweetInput,
  UpdateSweetInput,
  PurchaseInput,
  RestockInput,
} from '../types/index.js';
import { AppError } from '../middleware/errorHandler.js';

export const getAllSweets = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    const { data: sweets, error } = await supabase
      .from('sweets')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      return next(new AppError('Failed to fetch sweets', 500));
    }

    res.json({
      status: 'success',
      data: {
        sweets,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const searchSweets = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    const { name, category, minPrice, maxPrice } = req.query;

    let query = supabase.from('sweets').select('*');

    if (name) {
      query = query.ilike('name', `%${name}%`);
    }

    if (category) {
      query = query.eq('category', category);
    }

    if (minPrice) {
      query = query.gte('price', parseFloat(minPrice as string));
    }

    if (maxPrice) {
      query = query.lte('price', parseFloat(maxPrice as string));
    }

    const { data: sweets, error } = await query.order('created_at', {
      ascending: false,
    });

    if (error) {
      return next(new AppError('Failed to search sweets', 500));
    }

    res.json({
      status: 'success',
      data: {
        sweets,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const getSweetById = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    const { id } = req.params;

    const { data: sweet, error } = await supabase
      .from('sweets')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      return next(new AppError('Sweet not found', 404));
    }

    res.json({
      status: 'success',
      data: {
        sweet,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const createSweet = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    if (!req.user) {
      return next(new AppError('Authentication required', 401));
    }

    const { name, category, description, price, quantity, image_url }: CreateSweetInput =
      req.body;

    if (!name || !category || price === undefined || quantity === undefined) {
      return next(
        new AppError('Name, category, price, and quantity are required', 400)
      );
    }

    if (price < 0) {
      return next(new AppError('Price must be non-negative', 400));
    }

    if (quantity < 0) {
      return next(new AppError('Quantity must be non-negative', 400));
    }

    const { data: sweet, error } = await supabase
      .from('sweets')
      .insert({
        name,
        category,
        description,
        price,
        quantity,
        image_url,
        created_by: req.user.id,
      })
      .select()
      .single();

    if (error) {
      return next(new AppError('Failed to create sweet', 500));
    }

    res.status(201).json({
      status: 'success',
      data: {
        sweet,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const updateSweet = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    if (!req.user) {
      return next(new AppError('Authentication required', 401));
    }

    const { id } = req.params;
    const updates: UpdateSweetInput = req.body;

    if (updates.price !== undefined && updates.price < 0) {
      return next(new AppError('Price must be non-negative', 400));
    }

    if (updates.quantity !== undefined && updates.quantity < 0) {
      return next(new AppError('Quantity must be non-negative', 400));
    }

    const { data: existingSweet, error: fetchError } = await supabase
      .from('sweets')
      .select('created_by')
      .eq('id', id)
      .single();

    if (fetchError) {
      return next(new AppError('Sweet not found', 404));
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', req.user.id)
      .single();

    if (
      existingSweet.created_by !== req.user.id &&
      profile?.role !== 'admin'
    ) {
      return next(
        new AppError('Not authorized to update this sweet', 403)
      );
    }

    const { data: sweet, error } = await supabase
      .from('sweets')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      return next(new AppError('Failed to update sweet', 500));
    }

    res.json({
      status: 'success',
      data: {
        sweet,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const deleteSweet = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    if (!req.user) {
      return next(new AppError('Authentication required', 401));
    }

    const { id } = req.params;

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', req.user.id)
      .single();

    if (profile?.role !== 'admin') {
      return next(new AppError('Admin access required', 403));
    }

    const { error } = await supabase.from('sweets').delete().eq('id', id);

    if (error) {
      return next(new AppError('Failed to delete sweet', 500));
    }

    res.json({
      status: 'success',
      message: 'Sweet deleted successfully',
    });
  } catch (error) {
    next(error);
  }
};

export const purchaseSweet = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    if (!req.user) {
      return next(new AppError('Authentication required', 401));
    }

    const { id } = req.params;
    const { quantity }: PurchaseInput = req.body;

    if (!quantity || quantity <= 0) {
      return next(new AppError('Quantity must be greater than 0', 400));
    }

    const { data: sweet, error: fetchError } = await supabase
      .from('sweets')
      .select('*')
      .eq('id', id)
      .single();

    if (fetchError) {
      return next(new AppError('Sweet not found', 404));
    }

    if (sweet.quantity < quantity) {
      return next(
        new AppError(`Insufficient stock. Only ${sweet.quantity} available`, 400)
      );
    }

    const newQuantity = sweet.quantity - quantity;
    const totalPrice = sweet.price * quantity;

    const { error: updateError } = await supabase
      .from('sweets')
      .update({ quantity: newQuantity })
      .eq('id', id);

    if (updateError) {
      return next(new AppError('Failed to update inventory', 500));
    }

    const { data: purchase, error: purchaseError } = await supabase
      .from('purchase_history')
      .insert({
        sweet_id: id,
        user_id: req.user.id,
        quantity,
        total_price: totalPrice,
      })
      .select()
      .single();

    if (purchaseError) {
      return next(new AppError('Failed to record purchase', 500));
    }

    res.json({
      status: 'success',
      message: 'Purchase successful',
      data: {
        purchase,
        remainingStock: newQuantity,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const restockSweet = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    if (!req.user) {
      return next(new AppError('Authentication required', 401));
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', req.user.id)
      .single();

    if (profile?.role !== 'admin') {
      return next(new AppError('Admin access required', 403));
    }

    const { id } = req.params;
    const { quantity }: RestockInput = req.body;

    if (!quantity || quantity <= 0) {
      return next(new AppError('Quantity must be greater than 0', 400));
    }

    const { data: sweet, error: fetchError } = await supabase
      .from('sweets')
      .select('quantity')
      .eq('id', id)
      .single();

    if (fetchError) {
      return next(new AppError('Sweet not found', 404));
    }

    const newQuantity = sweet.quantity + quantity;

    const { data: updatedSweet, error: updateError } = await supabase
      .from('sweets')
      .update({ quantity: newQuantity })
      .eq('id', id)
      .select()
      .single();

    if (updateError) {
      return next(new AppError('Failed to restock sweet', 500));
    }

    res.json({
      status: 'success',
      message: 'Restock successful',
      data: {
        sweet: updatedSweet,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const getPurchaseHistory = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  try {
    if (!req.user) {
      return next(new AppError('Authentication required', 401));
    }

    const { data: purchases, error } = await supabase
      .from('purchase_history')
      .select('*, sweets(*)')
      .eq('user_id', req.user.id)
      .order('created_at', { ascending: false });

    if (error) {
      return next(new AppError('Failed to fetch purchase history', 500));
    }

    res.json({
      status: 'success',
      data: {
        purchases,
      },
    });
  } catch (error) {
    next(error);
  }
};
